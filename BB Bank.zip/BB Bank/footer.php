    <!--footer-->
    
    <div class="container bg-body-tertiary border-top border-success border-5">
      <div class="row">
        <div class="col-lg-4">
          <h4>CONTACT</h4>
          <ul class=" list-unstyled p-0 m-0">
            <li> Bangladesh Bank, Motijheel, Dhaka </li>
            <li>Phone: +880-255665001-6  </li>
            <li>E-mail: webmaster@bb.org.bd</li>
            </ul>
            <p class="border-bottom border-top pt-2">Contact for other purposes</p>
        </div>
        <div class="col-lg-4">
          <h4>USEFUL LINKS</h4>
          <a href="" class="text-decoration-none text-black">
          <ul class=" list-unstyled p-0 m-0">
            <li>>Payment Systems</li>
            <li>>Regulations And Guidelines</li>
            <li>>Currency Museum</li>
            <li>>SAARC Finance</li>
            <li>>Financial Literacy</li>
            <li>>National ICT Policy</li>
            </ul>
          </a>
        </div>
        <div class="col-lg-4">
          <h4>STAY CONNECTED</h4>
          <ul class="d-flex list-unstyled">
            <li><a href="" class="btn border border-secondary rounded-circle  me-2"><i class="bi bi-facebook pe-2" style="color: darkblue;"></i></a></li>
            <li><a href="" class="btn border border-secondary rounded-circle  me-2"><i class="bi bi-twitter pe-2" style="color: darkblue;"></i></a></li>
            <li><a href="" class="btn border border-secondary rounded-circle  me-2"><i class="bi bi-youtube pe-2" style="color: darkblue;"></i></a></li>
        </ul>
        </div>
    
        <div class="col-lg-12">
          <nav class="navbar navbar-expand-lg py-0;">
            <div class="container">
              
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
        
                <ul class="navbar-nav text-center">
                      <li class="nav-item border-end border-secondary">
                        <a class="nav-link active" aria-current="page" href="#">
                           Home </a>
                      </li>
                      <li class="nav-item border-end border-secondary">
                        <a class="nav-link active" href="#"> Sitemap </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Feedback </a>
                      </li>
                </ul> 
            </div>
            </div>
          </nav>
        </div>
    
        <p class="text-center"><span style="font-weight: bold;">Disclaimer:</span> While every effort is made to ensure accuracy of the information in this website, Bangladesh Bank assumes no responsibility for any damages or losses to users resulting from any error/omission/inadvertent alteration in information provided by this website.</p>
      </div>
    </div>
    
    
    </body>
    </html>