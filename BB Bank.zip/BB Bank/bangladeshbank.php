<?php get_header(); ?>
<body>
    <div class="container" style="background-color: #006666; color: white;">
        <div class="row">
            <div class="col-lg-1">
              <nav class="navbar">
                <div class="container">
                  <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
                    <div class="offcanvas-header">
                      <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Offcanvas</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                      <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                        
                        <li class="nav-item dropdown">
                          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            ABOUT US
                          </a>
                          <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">Action</a></li>
                            <li><a class="dropdown-item" href="#">Another action</a></li>
                            <li>
                              <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                          </ul>
                        </li>

                        <li class="nav-item dropdown">
                          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            MONETARY POLICY
                          </a>
                          <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">Action</a></li>
                            <li><a class="dropdown-item" href="#">Another action</a></li>
                            <li>
                              <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                          </ul>
                        </li>

                        <li class="nav-item dropdown">
                          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Department Offices
                          </a>
                          <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">Action</a></li>
                            <li><a class="dropdown-item" href="#">Another action</a></li>
                            <li>
                              <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                          </ul>
                        </li>


                        <li class="nav-item dropdown">
                          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Dropdown
                          </a>
                          <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">Action</a></li>
                            <li><a class="dropdown-item" href="#">Another action</a></li>
                            <li>
                              <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                          </ul>
                        </li>

                      </ul>
                    </div>
                    
                  </div>
                </div>
              </nav>    
              
            </div>
<!--searchbar-->
            <div class="col-lg-3 mt-2 text-start">
                <form class="d-flex border-bottom border-tertiary" role="search">
                  <input type="text" class="search_input" style="background-color: transparent;
                  border: none;" name="search_key" placeholder="Search">
                  <button class="btn text-white" type="submit">
                    <i class="bi bi-search text-end m-0"></i>
                  </button>
                </form>  
            </div>

            <div class="col-lg-8 mt-2 text-end">
               <a href="" class="text-end text-white text-decoration-none"><p>বাংলা</p></a>
            </div>
            </div>
        </div>
    

    <div class="container px-0">
        <div class="row  position-relative">
            <div class="col-lg-12">
                <img src="<?php bloginfo('template_directory'); ?>/BB Image/logo.jpg" class="w-100" alt="">
                <nav class="navbar navbar-expand-lg bg-body-tertiary position-absolute end-0 bottom-0 py-0 mb-2">
                      <div class="container" >
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                          <ul class="navbar-nav me-auto text-end">
                            <li class="nav-item">
                              <a class="nav-link active" aria-current="page" href="#">ABOUT US</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link active" aria-current="page" href="#">MONETARY POLICY</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link active" href="#">FINANCIAL SYSTEM</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link active" href="#">PUBLICATION</a>
                            </li>
                          </ul>
                        </div>
                      </div>
                </nav>
            </div>
        </div>
    </div>

    <div class="container mt-4 bg-body-tertiary">
        <div class="row">
            <div class="col-lg-8 border border-5 border-tertiary">
                <div id="carouselExample" class="carousel slide">
                    
                    <div class="carousel-inner">
                      <div class="carousel-item active">
                        <img src="<?php bloginfo('template_directory'); ?>/BB Image/slide 1.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="carousel-item">
                        <img src="<?php bloginfo('template_directory'); ?>/BB Image/slide 2.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="carousel-item">
                        <img src="<?php bloginfo('template_directory'); ?>/BB Image/slide 3.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="carousel-item">
                        <img src="<?php bloginfo('template_directory'); ?>/BB Image/slide 4.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="carousel-item">
                        <img src="<?php bloginfo('template_directory'); ?>/BB Image/slide 5.jpg" class="d-block w-100" alt="...">
                      </div>
                    </div>
                   
                  </div>    
            </div>

            <div class="col-lg-4 bg-body-tertiary">
             <h4 style="background-color: #00B16A;" class="text-white p-2">HONORABLE GOVERNOR
             </h4>
                <div class="card mb-3" style="max-width: 540px;">
                    <div class="row g-0">
                      <div class="col-md-4">
                        <img src="<?php bloginfo('template_directory'); ?>/BB Image/governor.jpg" class="img-fluid rounded-start" alt="...">
                      </div>
                      <div class="col-lg-8">
                        <div class="card-body">
                          <h5 class="card-title">MR. ABDUR ROUF TALUKDER</h5>
                          <p class="card-text">HONORABLE GOVERNOR OF BANGLADESH BANK</p>
                          <button type="button" class="btn btn-light">More...</button>
                        </div>
                      </div>
                    </div>
                </div>
            
            </div>
        </div>
    </div>
    
<!--search-->
<div class="container">
    <div class="row">
        <div class="col-lg-2" >
            <button type="button" style="background-color: #00B16A; color: white; font-weight: 700; padding-left: 10px;">RECENT NEWS</button>
        </div>

        <div class="col-lg-10">
            <marquee behavior="" direction="dropdown" class="bg-body-tertiary">

            DBI-3 Circular Letter No. 01: List of Audit Firms (Chartered Accountants) Eligible for Auditing Banks and Finance Companies.
Rules for External Audit of Bank-Companies, 2024 -- Feedback/Comments/Suggestions to be sent at shahana.nasrin@bb.org.bd and mmahmudur.rahman@bb.org.bd
BRPD Circular No. 02: Formation of Board and Responsibilities of Directors of a Bank-Company.
BRPD Circular Letter No. 08: Participation in Universal Pension Scheme.
DOS Circular Letter No. 04: Keeping scheduled bank branches closed in the election area on 12th February 2024 Monday for Election of 47 Naogaon-2 of National Parliament.
FEPD Circular No. 04: Interest rate ceiling for short term permissible trade finance in foreign exchange
DID Circular No. 01: Regarding Submission of Information for Deposit Insurance Premium Assessment
BRPD Circular Letter No. 07: Name change of South Bangla Agriculture and Commerce Bank Ltd to SBAC Bank PLC.
FEPD Circular No. 03: Inclusion of the name of Bangladesh Jute Goods Exporters Association for certificate in Jute sector for export subsidy
FEPD Circular No. 02: Export Subsidy/Cash Incentive for the financial year 2023-2024
ISMD Circular Letter No. 1: Master Circular Regarding Submission of Data to Integrated Supervision System (ISS)
114th Prizebond Draw held on 31st January, 2024   </marquee>
        </div>
    </div>
</div>

<div class="container mt-2">
    <div class="row">
        <div class="col-lg-9">
            <div class="row">
                <div class="col-lg-6 mb-3">
                    <div class="promo border-top shadow p-3 rounded border-3 border-success">
                        <h6 class="border-start border-3 border-success ps-2 mt-2">A title</h6>
                        <p class="float-start me-3 text-success" style="font-size: 80px;"> 
                            <i class="bi bi-suit-spade-fill"></i></p>
                            <ul class="list-unstyled pt-3">
                                <li> <a href=""> > MPS (January-June, 2024) </a></li>
                                <li><a href=""> > Monetary Policy Archive </a></li>
                                <li><a href=""> > MPC Resolution </a></li>
                                <li><a href=""> > Repo Reverse Repo Auction </a></li>
                            </ul>
                    </div>
                </div>

                <div class="col-lg-6 mb-3">
                    <div class="promo border-top shadow p-3 rounded border-3 border-danger">
                        <h6 class="border-start border-3 border-danger ps-2 mt-2">A title</h6>
                        <p class="float-start me-3 text-danger" style="font-size: 80px;"> 
                            <i class="bi bi-suit-spade-fill"></i></p>
                            <ul class="list-unstyled pt-3">
                                <li><a href=""> > MPS (January-June, 2024) </a></li>
                                <li><a href=""> > Monetary Policy Archive </a></li>
                                <li><a href=""> > MPC Resolution </a></li>
                                <li><a href=""> > Repo Reverse Repo Auction </a></li>
                            </ul>
                    </div>
                </div>

                <div class="col-lg-6 mb-3">
                    <div class="promo border-top shadow p-3 rounded border-3 border-success">
                        <h6 class="border-start border-3 border-success ps-2 mt-2">A title</h6>
                        <p class="float-start me-3 text-success" style="font-size: 80px;"> 
                            <i class="bi bi-suit-spade-fill"></i></p>
                            <ul class="list-unstyled pt-3">
                                <li> <a href=""> > MPS (January-June, 2024) </a></li>
                                <li><a href=""> > Monetary Policy Archive </a></li>
                                <li><a href=""> > MPC Resolution </a></li>
                                <li><a href=""> > Repo Reverse Repo Auction </a></li>
                            </ul>
                    </div>
                </div>

                <div class="col-lg-6 mb-3">
                    <div class="promo border-top shadow p-3 rounded border-3 border-danger">
                        <h6 class="border-start border-3 border-danger ps-2 mt-2">A title</h6>
                        <p class="float-start me-3 text-danger" style="font-size: 80px;"> 
                            <i class="bi bi-suit-spade-fill"></i></p>
                            <ul class="list-unstyled pt-3">
                                <li><a href=""> > MPS (January-June, 2024) </a></li>
                                <li><a href=""> > Monetary Policy Archive </a></li>
                                <li><a href=""> > MPC Resolution </a></li>
                                <li><a href=""> > Repo Reverse Repo Auction </a></li>
                            </ul>
                    </div>
                </div>

                <div class="col-lg-6 mb-3">
                    <div class="promo border-top shadow p-3 rounded border-3 border-success">
                        <h6 class="border-start border-3 border-success ps-2 mt-2">A title</h6>
                        <p class="float-start me-3 text-success" style="font-size: 80px;"> 
                            <i class="bi bi-suit-spade-fill"></i></p>
                            <ul class="list-unstyled pt-3">
                                <li> <a href=""> > MPS (January-June, 2024) </a></li>
                                <li><a href=""> > Monetary Policy Archive </a></li>
                                <li><a href=""> > MPC Resolution </a></li>
                                <li><a href=""> > Repo Reverse Repo Auction </a></li>
                            </ul>
                    </div>
                </div>

                <div class="col-lg-6 mb-3">
                    <div class="promo border-top shadow p-3 rounded border-3 border-danger">
                        <h6 class="border-start border-3 border-danger ps-2 mt-2">A title</h6>
                        <p class="float-start me-3 text-danger" style="font-size: 80px;"> 
                            <i class="bi bi-suit-spade-fill"></i></p>
                            <ul class="list-unstyled pt-3">
                                <li><a href=""> > MPS (January-June, 2024) </a></li>
                                <li><a href=""> > Monetary Policy Archive </a></li>
                                <li><a href=""> > MPC Resolution </a></li>
                                <li><a href=""> > Repo Reverse Repo Auction </a></li>
                            </ul>
                    </div>
                </div>

                <div class="col-lg-6 mb-3">
                    <div class="promo border-top shadow p-3 rounded border-3 border-success">
                        <h6 class="border-start border-3 border-success ps-2 mt-2">A title</h6>
                        <p class="float-start me-3 text-success" style="font-size: 80px;"> 
                            <i class="bi bi-suit-spade-fill"></i></p>
                            <ul class="list-unstyled pt-3">
                                <li> <a href=""> > MPS (January-June, 2024) </a></li>
                                <li><a href=""> > Monetary Policy Archive </a></li>
                                <li><a href=""> > MPC Resolution </a></li>
                                <li><a href=""> > Repo Reverse Repo Auction </a></li>
                            </ul>
                    </div>
                </div>

                <div class="col-lg-6 mb-3">
                    <div class="promo border-top shadow p-3 rounded border-3 border-danger">
                        <h6 class="border-start border-3 border-danger ps-2 mt-2">A title</h6>
                        <p class="float-start me-3 text-danger" style="font-size: 80px;"> 
                            <i class="bi bi-suit-spade-fill"></i></p>
                            <ul class="list-unstyled pt-3">
                                <li><a href=""> > MPS (January-June, 2024) </a></li>
                                <li><a href=""> > Monetary Policy Archive </a></li>
                                <li><a href=""> > MPC Resolution </a></li>
                                <li><a href=""> > Repo Reverse Repo Auction </a></li>
                            </ul>
                    </div>
                </div>

                <div class="col-lg-6 mb-3">
                    <div class="promo border-top shadow p-3 rounded border-3 border-success">
                        <h6 class="border-start border-3 border-success ps-2 mt-2">A title</h6>
                        <p class="float-start me-3 text-success" style="font-size: 80px;"> 
                            <i class="bi bi-suit-spade-fill"></i></p>
                            <ul class="list-unstyled pt-3">
                                <li> <a href=""> > MPS (January-June, 2024) </a></li>
                                <li><a href=""> > Monetary Policy Archive </a></li>
                                <li><a href=""> > MPC Resolution </a></li>
                                <li><a href=""> > Repo Reverse Repo Auction </a></li>
                            </ul>
                    </div>
                </div>

                <div class="col-lg-6 mb-3">
                    <div class="promo border-top shadow p-3 rounded border-3 border-danger">
                        <h6 class="border-start border-3 border-danger ps-2 mt-2">A title</h6>
                        <p class="float-start me-3 text-danger" style="font-size: 80px;"> 
                            <i class="bi bi-suit-spade-fill"></i></p>
                            <ul class="list-unstyled pt-3">
                                <li><a href=""> > MPS (January-June, 2024) </a></li>
                                <li><a href=""> > Monetary Policy Archive </a></li>
                                <li><a href=""> > MPC Resolution </a></li>
                                <li><a href=""> > Repo Reverse Repo Auction </a></li>
                            </ul>
                    </div>
                </div>
<!--table-->
<div class="container bg-body-tertiary mt-2">
        <div class="row">
              <div class="col-lg-3">
                <table class="table table-borderless">
                    <h5>Policy Rate</h5>
                    
                    <tbody>
                      <tr>
                        <td>Policy Rate (Repo Rate)</td>
                        <td>8.00%</td>
                      </tr>
                      <tr>
                        <td> SLF Rate</td>
                        <td>9.50%</td>
                      </tr>
                      <tr>
                        <td>SDF Rate</td>
                        <td>6.50%</td>
                      </tr>
                      <tr>
                        <td>Bank Rate</td>
                        <td>4.00%</td>
                      </tr>
                    </tbody>
                  </table>
              </div> 
             <!--2nd table-->
              <div class="col-lg-5">
                <table class="table table-borderless">
                    <h5> RESERVE RATIOS</h5>
                    
                    <thead>
                      <th></th>
                      <th>SLR</th>
                      <th>CRR</th>
                    </thead>

                    <tbody>
                      <tr>
                        <td>Traditional Banking</td>
                        <td>13%	</td>
                        <td>	4.0%	</td>
                      </tr>
                      <tr>
                        <td> Islamic Banking	</td>
                        <td>5.5%</td>
                        <td>4.0%</td>
                      </tr>
                      <tr>
                        <td> Deposit Taker FIs</td>
                        <td>5%	</td>
                        <td>1.5%	</td>
                      </tr>
                      <tr>
                        <td>Non Deposit Taker FIs</td>
                        <td>2.5%</td>
                      </tr>
                    </tbody>
                  </table>
                  <p style="color: #DC3545; font-style: italic;">*Last update: 30.06.2019</p>
              </div> 

              <!--3rd table-->
              <div class="col-lg-4">
                <table class="table table-borderless">
                    <h5>Policy Rate</h5>
                    
                    <thead>
                      <th></th>
                      <th>CURRENCY</th>
                      <th>LOWEST</th>
                      <th>HIGHEST</th>
                    </thead>

                    <tbody>
                      <tr>
                        <td>USD</td>
                        <td>110.0000</td>
                        <td>110.0000</td>
                      </tr>
                    </tbody>
                  </table>

                <p style="color: #DC3545; font-style: italic;">*Last update: 14th February, 2024</p>
                <p style="color: #DC3545; font-style: italic;">*[Source: BAFEDA]</p>

                <button class="btn" style="background-color: #006666;color: white;">READ MORE</button>
              </div> 


        </div>
  </div>
  </div>
  </div>
        
<!--sidebar 1st-->
<div class="col-lg-3">
    <div class="container mt-3 mb-3">
      <div class="row">
      <div class="row bg-body-tertiary">
        <h5 style="color: #DC3545; font-weight: bold;"> ICT SECURITY ALERT</h5>
        <p><a href="" class="text-decoration-none" style="color: darkblue;">ICT Security Advisories & Alerts</a></p>
      </div>
    </div>
    </div>
 <!--2nd-->   
    <div class="container mt-3 mb-3">
      <div class="row">
      <div class="row bg-body-tertiary">
        <h5 style="color: #DC3545; font-weight: bold;"> CUSTOMERS' INTEREST PROTECTION CENTER(CIPC)</h5>
        <p style="color: green; font-weight: bold;"> FOR ANY COMPLAINT</p>
        <p style="font-size: 35px; text-align: center;" class="m-0"> Call: 16236</p>
        <a href="" class="text-decoration-none p-0 m-0" style=" text-align: center;">Email: bb.cipc@bb.org.bd</a>
        <a href="" class="text-decoration-none p-0 m-0" style="color: darkblue; text-align: center;"><p class="p-0 m-0">Download Mobile App
        </p></a>
      <a href="" class="text-decoration-none" style="color: darkblue; text-align: center;"><p class="p-0 m-0">
        Submit Online</p></a>
      </div>
    </div>
    </div>
  <!--3rd-->
    <div class="col-lg-12 mt-3 mb-3">
      <div class="cart w-100 h-2" style="background-color: #F7F5F3;">
        <div class="card-body">
          <h5 class="card-title" style="color: #DC3545; font-weight: semibold;font-size: 16px;">Six-months Moving Average Rate of Treasury bill (SMART)</h5>
          <p style="font-size: 12px;" class="text-center">January,2024 <br> (Application for February,2024)</p>
          <h2 class="text-center">8.68</h2>
          <p class="text-center" style="color:#0000FF; font-size: 14px;font-weight: semibold;"><a href="" class="text-decoration-none">Previous 6 months' SMART</a></p>
       
    
    
          <p class="text-danger text-center fw-bold">__________________________</p>
          <h5 class="text-danger fw-semibold">CALL MONEY RATE</h5>
          <h6 class="text-center">11 February,2024</h6>
          <p class="text-center"><a href="" class="text-decoration-none">Weighted Average Interest Rate</a></p>
          <h2 class="text-center">9.28</h2>
          <p class="text-end"><a href="" class="text-decoration-none">View all</a></p>
          <h6 class="text-danger" style="font-weight: semibold;">UPCOMING AUCTIONS</h6>
    
    
          <table class=" mb-4 border-top border-1 border-dark">
            <tbody >
              <tr >
                <td style="color:#009978; font-weight: bold;">BOND</td>
    
                <td>February, 2024</td>
                <td style="background-color: #FA6742;">13</td>
              </tr>
            </tbody>
          </table>
          <hr>
          <table class="  mb-4 border-top border-1 border-dark">
            <tbody>
              <tr  >
                <td style="color:#009978; font-weight: bold;">BOND</td>
                <td>February, 2024</td>
                <td style="background-color: #FA6742;">15</td>
              </tr>
            </tbody>
          </table>
          <hr>
          <p class="text-end mt-3 mb-0"><a href="#" class="text-decoration-none ">View all<i class="bi bi-arrow-right"></i></a></p>
        </div>
      </div>
    </div>
<!--4th-->
    <div class="container mt-3 mb-3">
      <div class="row">
      <div class="row bg-body-tertiary">
        <h5 style="color: #DC3545; font-weight: bold;">EMERGENCY HOTLINE</h5>
        <img src="<?php bloginfo('template_directory'); ?>/BB Image/images12.jpg" class="w-70" alt="">
      </div>
    </div>
    </div>
     
    
    </div>
    <!--other-->
    
            </div>
        </div>
    
        <?php get_footer(); ?>
