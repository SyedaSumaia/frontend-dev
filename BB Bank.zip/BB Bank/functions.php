<?php
// Styles and scripts file call
function my_theme_enqueue_styles() {
    wp_enqueue_style('bootstrap-css', get_template_directory_uri() . '/css/bootstrap.min.css', array(), '5.2.3', 'all');
    wp_enqueue_style('bootstrap-icons-css', get_template_directory_uri() . '/css/bootstrap-icons.min.css', array(), '1.7.2', 'all');
    wp_enqueue_style('custom-css', get_template_directory_uri() . '/style.css', array(), '1.0', 'all');

    wp_enqueue_script('bootstrap-js', get_template_directory_uri() . '/js/bootstrap.bundle.min.js', array('jquery'), '5.2.3', true);
}
add_action('wp_enqueue_scripts', 'my_theme_enqueue_styles');

// Custom logo support
function my_theme_custom_logo_setup() {
    add_theme_support('custom-logo', array(
        'height' => 60,
        'width' => 160,
        'flex-height' => true,
        'flex-width' => true,
    ));
}
add_action('after_setup_theme', 'my_theme_custom_logo_setup');

// Register navigation menu
function my_theme_register_menus() {
    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'bootstrap' ),
    ) );
}
add_action('after_setup_theme', 'my_theme_register_menus');

/**
 * Register Custom Navigation Walker
 */
function register_navwalker(){
	require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';
}
add_action( 'after_setup_theme', 'register_navwalker' );